var ItemsModel = {
    items : ["Vinicius","Wilckerson","Del"]   
}